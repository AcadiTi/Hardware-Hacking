# RF_HT6P20
Biblioteca para IDE arduino que decodifica os controles RF baseados no chip HT6P20

-Decodifica e codifica 

![ScreenShot](https://github.com/lucasmaziero/RF_HT6P20/blob/master/Uno-RF-433-Receptor.png)
